package study.jsprendering;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleWebAppTomcatApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleWebAppTomcatApplication.class, args);
	}
}